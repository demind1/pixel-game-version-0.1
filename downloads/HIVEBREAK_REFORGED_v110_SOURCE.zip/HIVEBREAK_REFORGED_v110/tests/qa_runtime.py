"""Compatibility entry point; the maintained suite uses real HTTP assets."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name('browser_regression.py')), run_name='__main__')
